CREATE VIEW `v_user_modules` AS
  SELECT
    `jg_teachers`.`t_users`.`id`           AS `user_id`,
    `jg_teachers`.`t_users_role`.`id`      AS `users_role_id`,
    `jg_teachers`.`t_role_modules`.`id`    AS `role_module_id`,
    `jg_teachers`.`t_users`.`account`      AS `user_account`,
    `jg_teachers`.`t_modules`.`id`         AS `module_id`,
    `jg_teachers`.`t_modules`.`name`       AS `module_name`,
    `jg_teachers`.`t_modules`.`father_id`  AS `module_father_id`,
    `jg_teachers`.`t_modules`.`level`      AS `module_level`,
    `jg_teachers`.`t_modules`.`sequence`   AS `module_sequence`,
    `jg_teachers`.`t_modules`.`is_default` AS `module_is_default`,
    `jg_teachers`.`t_modules`.`url`        AS `module_url`,
    `jg_teachers`.`t_modules`.`status`     AS `module_status`
  FROM ((((`jg_teachers`.`t_users`
    JOIN `jg_teachers`.`t_users_role` ON ((`jg_teachers`.`t_users_role`.`user_id` = `jg_teachers`.`t_users`.`id`))) JOIN
    `jg_teachers`.`t_roles` ON ((`jg_teachers`.`t_users_role`.`role_id` = `jg_teachers`.`t_roles`.`id`))) JOIN
    `jg_teachers`.`t_role_modules` ON ((`jg_teachers`.`t_role_modules`.`role_id` = `jg_teachers`.`t_roles`.`id`))) JOIN
    `jg_teachers`.`t_modules` ON ((`jg_teachers`.`t_role_modules`.`module_id` = `jg_teachers`.`t_modules`.`id`)))