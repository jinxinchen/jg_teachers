CREATE VIEW `v_project` AS
  SELECT
    `jg_teachers`.`t_project_user`.`user_id`                      AS `user_id`,
    `jg_teachers`.`t_scientific`.`id`                             AS `id`,
    `jg_teachers`.`t_scientific`.`scientific_name`                AS `scientific_name`,
    `jg_teachers`.`t_scientific`.`scientific_source`              AS `scientific_source`,
    `jg_teachers`.`t_scientific`.`type`                           AS `type`,
    `jg_teachers`.`t_scientific`.`level`                          AS `level`,
    `jg_teachers`.`t_scientific`.`member_list`                    AS `member_list`,
    `jg_teachers`.`t_scientific`.`is_march`                       AS `is_march`,
    `jg_teachers`.`t_scientific`.`create_time`                    AS `create_time`,
    `jg_teachers`.`t_scientific`.`end_time`                       AS `end_time`,
    `jg_teachers`.`t_scientific`.`grants`                         AS `grants`,
    `jg_teachers`.`t_scientific`.`create_scientific_evidence_src` AS `create_scientific_evidence_src`,
    `jg_teachers`.`t_scientific`.`create_update_time`             AS `create_update_time`,
    `jg_teachers`.`t_scientific`.`end_scientific_evidence_src`    AS `end_scientific_evidence_src`,
    `jg_teachers`.`t_scientific`.`end_update_time`                AS `end_update_time`,
    `jg_teachers`.`t_scientific`.`others`                         AS `others`,
    `jg_teachers`.`t_scientific`.`status`                         AS `status`
  FROM (`jg_teachers`.`t_project_user`
    JOIN `jg_teachers`.`t_scientific`
      ON ((`jg_teachers`.`t_project_user`.`project_id` = `jg_teachers`.`t_scientific`.`id`)))