CREATE VIEW `v_admin_copyright` AS
  SELECT
    `jg_teachers`.`t_copyright`.`id`                 AS `id`,
    `jg_teachers`.`t_copyright`.`user_id`            AS `user_id`,
    `jg_teachers`.`t_copyright`.`owner_name`         AS `owner_name`,
    `jg_teachers`.`t_copyright`.`title`              AS `title`,
    `jg_teachers`.`t_copyright`.`type`               AS `type`,
    `jg_teachers`.`t_copyright`.`publish_name`       AS `publish_name`,
    `jg_teachers`.`t_copyright`.`publishTime`        AS `publishTime`,
    `jg_teachers`.`t_copyright`.`publish_id`         AS `publish_id`,
    `jg_teachers`.`t_copyright`.`other_participator` AS `other_participator`,
    `jg_teachers`.`t_copyright`.`notice`             AS `notice`,
    `jg_teachers`.`t_copyright`.`status`             AS `status`,
    `jg_teachers`.`t_teacher_baseinfo`.`name`        AS `name`,
    `jg_teachers`.`t_copyright`.`ISSBN`              AS `ISSBN`
  FROM (`jg_teachers`.`t_copyright`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_copyright`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)))