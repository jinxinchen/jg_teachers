CREATE VIEW `v_admin_article` AS
  SELECT
    `jg_teachers`.`t_article`.`id`                AS `id`,
    `jg_teachers`.`t_article`.`user_id`           AS `user_id`,
    `jg_teachers`.`t_article`.`article_name`      AS `article_name`,
    `jg_teachers`.`t_article`.`level`             AS `level`,
    `jg_teachers`.`t_article`.`post_time`         AS `post_time`,
    `jg_teachers`.`t_article`.`publication_name`  AS `publication_name`,
    `jg_teachers`.`t_article`.`publication_id`    AS `publication_id`,
    `jg_teachers`.`t_article`.`publication_level` AS `publication_level`,
    `jg_teachers`.`t_article`.`is_call`           AS `is_call`,
    `jg_teachers`.`t_article`.`articleSrc`        AS `article_src`,
    `jg_teachers`.`t_article`.`article_level`     AS `article_level`,
    `jg_teachers`.`t_article`.`notice`            AS `notice`,
    `jg_teachers`.`t_article`.`status`            AS `status`,
    `jg_teachers`.`t_teacher_baseinfo`.`name`     AS `uname`,
    `jg_teachers`.`t_article`.`file_name`         AS `file_name`,
    `jg_teachers`.`t_article`.`periods`           AS `periods`,
    `jg_teachers`.`t_article`.`nums`              AS `nums`,
    `jg_teachers`.`t_article`.`type`              AS `type`,
    `jg_teachers`.`t_article`.`articleSrc`        AS `articleSrc`
  FROM (`jg_teachers`.`t_article`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_article`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)))