CREATE VIEW `v_messageboard` AS
  SELECT
    `jg_teachers`.`t_message_aboard`.`id`       AS `id`,
    `jg_teachers`.`t_message_aboard`.`message`  AS `message`,
    `jg_teachers`.`t_message_aboard`.`dateTime` AS `dateTime`,
    `jg_teachers`.`t_teacher_baseinfo`.`name`   AS `name`,
    `jg_teachers`.`t_message_aboard`.`status`   AS `status`,
    `jg_teachers`.`t_message_aboard`.`user_id`  AS `user_id`
  FROM (`jg_teachers`.`t_teacher_baseinfo`
    JOIN `jg_teachers`.`t_message_aboard`
      ON ((`jg_teachers`.`t_teacher_baseinfo`.`user_id` = `jg_teachers`.`t_message_aboard`.`user_id`)))