CREATE VIEW `v_admin_abilityproject` AS
  SELECT
    `jg_teachers`.`t_teacher_baseinfo`.`name`              AS `name`,
    `jg_teachers`.`t_ability_project`.`id`                 AS `id`,
    `jg_teachers`.`t_ability_project`.`user_id`            AS `user_id`,
    `jg_teachers`.`t_ability_project`.`prize_id`           AS `prize_id`,
    `jg_teachers`.`t_ability_project`.`prize_name`         AS `prize_name`,
    `jg_teachers`.`t_ability_project`.`prize_level`        AS `prize_level`,
    `jg_teachers`.`t_ability_project`.`unit_of_prizes`     AS `unit_of_prizes`,
    `jg_teachers`.`t_ability_project`.`winner`             AS `winner`,
    `jg_teachers`.`t_ability_project`.`win_time`           AS `win_time`,
    `jg_teachers`.`t_ability_project`.`funds`              AS `funds`,
    `jg_teachers`.`t_ability_project`.`file_name`          AS `file_name`,
    `jg_teachers`.`t_ability_project`.`prize_evidence_src` AS `prize_evidence_src`,
    `jg_teachers`.`t_ability_project`.`upload_time`        AS `upload_time`,
    `jg_teachers`.`t_ability_project`.`notice`             AS `notice`,
    `jg_teachers`.`t_ability_project`.`status`             AS `status`
  FROM (`jg_teachers`.`t_teacher_baseinfo`
    JOIN `jg_teachers`.`t_ability_project`
      ON ((`jg_teachers`.`t_ability_project`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)))