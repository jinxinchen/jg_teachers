CREATE VIEW `v_users_role_baseinfo` AS
  SELECT
    `jg_teachers`.`t_teacher_baseinfo`.`id`                AS `id`,
    `jg_teachers`.`t_teacher_baseinfo`.`user_id`           AS `user_id`,
    `jg_teachers`.`t_teacher_baseinfo`.`name`              AS `name`,
    `jg_teachers`.`t_teacher_baseinfo`.`gender`            AS `gender`,
    `jg_teachers`.`t_teacher_baseinfo`.`birthday`          AS `birthday`,
    `jg_teachers`.`t_teacher_baseinfo`.`email`             AS `email`,
    `jg_teachers`.`t_teacher_baseinfo`.`identityNum`       AS `identityNum`,
    `jg_teachers`.`t_teacher_baseinfo`.`picture`           AS `picture`,
    `jg_teachers`.`t_teacher_baseinfo`.`create_time`       AS `create_time`,
    `jg_teachers`.`t_teacher_baseinfo`.`address`           AS `address`,
    `jg_teachers`.`t_teacher_baseinfo`.`phoneNum`          AS `phoneNum`,
    `jg_teachers`.`t_teacher_baseinfo`.`is_more_langue`    AS `is_more_langue`,
    `jg_teachers`.`t_teacher_baseinfo`.`major`             AS `major`,
    `jg_teachers`.`t_teacher_baseinfo`.`is_tutor`          AS `is_tutor`,
    `jg_teachers`.`t_teacher_baseinfo`.`tutor_class`       AS `tutor_class`,
    `jg_teachers`.`t_teacher_baseinfo`.`adminFunction`     AS `adminFunction`,
    `jg_teachers`.`t_teacher_baseinfo`.`academicSecretary` AS `academicSecretary`,
    `jg_teachers`.`t_teacher_baseinfo`.`for_class`         AS `for_class`,
    `jg_teachers`.`t_teacher_baseinfo`.`research`          AS `research`,
    `jg_teachers`.`t_teacher_baseinfo`.`socialFunction`    AS `socialFunction`,
    `jg_teachers`.`t_teacher_baseinfo`.`degree`            AS `degree`,
    `jg_teachers`.`t_teacher_baseinfo`.`degree_type`       AS `degree_type`,
    `jg_teachers`.`t_teacher_baseinfo`.`status`            AS `status`,
    `jg_teachers`.`t_users_role`.`role_id`                 AS `role_id`
  FROM (`jg_teachers`.`t_users_role`
    JOIN `jg_teachers`.`t_teacher_baseinfo`
      ON ((`jg_teachers`.`t_users_role`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)))