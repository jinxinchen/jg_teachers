create view v_teachers_prize_check as
  select `jg_teachers`.`t_teacher_baseinfo`.`name`                      AS `name`,
         `jg_teachers`.`t_educate_scientific`.`id`                      AS `id`,
         `jg_teachers`.`t_educate_scientific`.`user_id`                 AS `user_id`,
         `jg_teachers`.`t_educate_scientific`.`educate_scientific_name` AS `educate_scientific_name`,
         `jg_teachers`.`t_educate_scientific`.`prize_name`              AS `prize_name`,
         `jg_teachers`.`t_educate_scientific`.`prize_time`              AS `prize_time`,
         `jg_teachers`.`t_educate_scientific`.`the_unit`                AS `the_unit`,
         `jg_teachers`.`t_educate_scientific`.`school_name`             AS `school_name`,
         `jg_teachers`.`t_educate_scientific`.`author`                  AS `author`,
         `jg_teachers`.`t_educate_scientific`.`members_list`            AS `members_list`,
         `jg_teachers`.`t_educate_scientific`.`type`                    AS `type`,
         `jg_teachers`.`t_educate_scientific`.`others`                  AS `others`,
         `jg_teachers`.`t_educate_scientific`.`evidence_path`           AS `evidence_path`,
         `jg_teachers`.`t_educate_scientific`.`upload_time`             AS `upload_time`,
         `jg_teachers`.`t_educate_scientific`.`certify_number`          AS `certify_number`,
         `jg_teachers`.`t_educate_scientific`.`status`                  AS `status`,
         `jg_teachers`.`t_educate_scientific`.`file_name`               AS `file_name`
  from (`jg_teachers`.`t_teacher_baseinfo` join `jg_teachers`.`t_educate_scientific` on ((
    `jg_teachers`.`t_teacher_baseinfo`.`user_id` = `jg_teachers`.`t_educate_scientific`.`user_id`)));

