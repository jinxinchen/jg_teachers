create view v_project_user as
  select `jg_teachers`.`t_teacher_baseinfo`.`name`      AS `name`,
         `jg_teachers`.`t_project_user`.`id`            AS `id`,
         `jg_teachers`.`t_project_user`.`user_id`       AS `user_id`,
         `jg_teachers`.`t_project_user`.`project_id`    AS `project_id`,
         `jg_teachers`.`t_project_user`.`level`         AS `level`,
         `jg_teachers`.`t_project_user`.`is_principal`  AS `is_principal`,
         `jg_teachers`.`t_scientific`.`scientific_name` AS `scientific_name`
  from ((`jg_teachers`.`t_teacher_baseinfo` join `jg_teachers`.`t_project_user` on ((
    `jg_teachers`.`t_teacher_baseinfo`.`id` =
    `jg_teachers`.`t_project_user`.`user_id`))) join `jg_teachers`.`t_scientific` on ((
    `jg_teachers`.`t_project_user`.`project_id` = `jg_teachers`.`t_scientific`.`id`)));

