create view v_user_modules as
  select `jg_teachers`.`t_users`.`id`           AS `user_id`,
         `jg_teachers`.`t_users_role`.`id`      AS `users_role_id`,
         `jg_teachers`.`t_role_modules`.`id`    AS `role_module_id`,
         `jg_teachers`.`t_users`.`account`      AS `user_account`,
         `jg_teachers`.`t_modules`.`id`         AS `module_id`,
         `jg_teachers`.`t_modules`.`name`       AS `module_name`,
         `jg_teachers`.`t_modules`.`father_id`  AS `module_father_id`,
         `jg_teachers`.`t_modules`.`level`      AS `module_level`,
         `jg_teachers`.`t_modules`.`sequence`   AS `module_sequence`,
         `jg_teachers`.`t_modules`.`is_default` AS `module_is_default`,
         `jg_teachers`.`t_modules`.`url`        AS `module_url`,
         `jg_teachers`.`t_modules`.`status`     AS `module_status`
  from ((((`jg_teachers`.`t_users` join `jg_teachers`.`t_users_role` on ((`jg_teachers`.`t_users_role`.`user_id` =
                                                                          `jg_teachers`.`t_users`.`id`))) join `jg_teachers`.`t_roles` on ((
    `jg_teachers`.`t_users_role`.`role_id` = `jg_teachers`.`t_roles`.`id`))) join `jg_teachers`.`t_role_modules` on ((
    `jg_teachers`.`t_role_modules`.`role_id` = `jg_teachers`.`t_roles`.`id`))) join `jg_teachers`.`t_modules` on ((
    `jg_teachers`.`t_role_modules`.`module_id` = `jg_teachers`.`t_modules`.`id`)));

