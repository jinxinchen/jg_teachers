create view v_admin_copyright as
  select `jg_teachers`.`t_copyright`.`id`                 AS `id`,
         `jg_teachers`.`t_copyright`.`user_id`            AS `user_id`,
         `jg_teachers`.`t_copyright`.`owner_name`         AS `owner_name`,
         `jg_teachers`.`t_copyright`.`title`              AS `title`,
         `jg_teachers`.`t_copyright`.`type`               AS `type`,
         `jg_teachers`.`t_copyright`.`publish_name`       AS `publish_name`,
         `jg_teachers`.`t_copyright`.`publishTime`        AS `publishTime`,
         `jg_teachers`.`t_copyright`.`publish_id`         AS `publish_id`,
         `jg_teachers`.`t_copyright`.`other_participator` AS `other_participator`,
         `jg_teachers`.`t_copyright`.`notice`             AS `notice`,
         `jg_teachers`.`t_copyright`.`status`             AS `status`,
         `jg_teachers`.`t_teacher_baseinfo`.`name`        AS `name`,
         `jg_teachers`.`t_copyright`.`ISSBN`              AS `ISSBN`,
         `jg_teachers`.`t_copyright`.`copyRightSrc`       AS `copyRightSrc`,
         `jg_teachers`.`t_copyright`.`file_name`          AS `file_name`,
         `jg_teachers`.`t_copyright`.`upload_time`        AS `upload_time`
  from (`jg_teachers`.`t_copyright` join `jg_teachers`.`t_teacher_baseinfo` on ((`jg_teachers`.`t_copyright`.`user_id` =
                                                                                 `jg_teachers`.`t_teacher_baseinfo`.`user_id`)));

