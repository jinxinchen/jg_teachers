create view v_teachers_activity_check as
  select `jg_teachers`.`t_teacher_activity`.`id`                      AS `id`,
         `jg_teachers`.`t_teacher_activity`.`user_id`                 AS `user_id`,
         `jg_teachers`.`t_teacher_activity`.`activity_name`           AS `activity_name`,
         `jg_teachers`.`t_teacher_activity`.`activity_location`       AS `activity_location`,
         `jg_teachers`.`t_teacher_activity`.`activity_time`           AS `activity_time`,
         `jg_teachers`.`t_teacher_activity`.`activity_organizers`     AS `activity_organizers`,
         `jg_teachers`.`t_teacher_activity`.`others`                  AS `others`,
         `jg_teachers`.`t_teacher_activity`.`status`                  AS `status`,
         `jg_teachers`.`t_teacher_baseinfo`.`name`                    AS `teacher_name`,
         `jg_teachers`.`t_teacher_baseinfo`.`user_id`                 AS `baseinfo_userid`,
         `jg_teachers`.`t_teacher_activity`.`certificate`             AS `certificate`,
         `jg_teachers`.`t_teacher_activity`.`certificate_upload_time` AS `certificate_upload_time`
  from (`jg_teachers`.`t_teacher_activity` join `jg_teachers`.`t_teacher_baseinfo` on ((
    `jg_teachers`.`t_teacher_activity`.`user_id` = `jg_teachers`.`t_teacher_baseinfo`.`user_id`)));

