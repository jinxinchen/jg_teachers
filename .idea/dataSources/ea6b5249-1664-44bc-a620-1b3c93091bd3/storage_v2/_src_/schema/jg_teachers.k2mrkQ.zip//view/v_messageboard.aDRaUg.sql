create view v_messageboard as
  select `jg_teachers`.`t_message_aboard`.`id`       AS `id`,
         `jg_teachers`.`t_message_aboard`.`message`  AS `message`,
         `jg_teachers`.`t_message_aboard`.`dateTime` AS `dateTime`,
         `jg_teachers`.`t_teacher_baseinfo`.`name`   AS `name`,
         `jg_teachers`.`t_message_aboard`.`status`   AS `status`,
         `jg_teachers`.`t_message_aboard`.`user_id`  AS `user_id`
  from (`jg_teachers`.`t_teacher_baseinfo` join `jg_teachers`.`t_message_aboard` on ((
    `jg_teachers`.`t_teacher_baseinfo`.`user_id` = `jg_teachers`.`t_message_aboard`.`user_id`)));

