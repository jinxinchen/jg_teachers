create view v_admin_project as
  select `jg_teachers`.`t_scientific`.`user_id`       AS `user_id`,
         `jg_teachers`.`t_scientific`.`head_name`     AS `head_name`,
         `jg_teachers`.`t_teacher_baseinfo`.`user_id` AS `user_id_base`,
         `jg_teachers`.`t_teacher_baseinfo`.`name`    AS `name`,
         `jg_teachers`.`t_scientific`.`id`            AS `id`
  from (`jg_teachers`.`t_scientific` join `jg_teachers`.`t_teacher_baseinfo` on ((
    `jg_teachers`.`t_scientific`.`head_name` = `jg_teachers`.`t_teacher_baseinfo`.`name`)));

