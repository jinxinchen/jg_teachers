create view v_manageteachers_baseinfo as
  select `jg_teachers`.`t_users_role`.`role_id`                  AS `role_id`,
         `jg_teachers`.`t_teacher_baseinfo`.`name`               AS `name`,
         `jg_teachers`.`t_teacher_baseinfo`.`gender`             AS `gender`,
         `jg_teachers`.`t_teacher_baseinfo`.`user_id`            AS `user_id`,
         `jg_teachers`.`t_teacher_baseinfo`.`birthday`           AS `birthday`,
         `jg_teachers`.`t_teacher_baseinfo`.`phoneNum`           AS `phoneNum`,
         `jg_teachers`.`t_educate_degree`.`educate_degree_name`  AS `educate_degree_name`,
         `jg_teachers`.`t_teacher_baseinfo`.`degree`             AS `degree`,
         `jg_teachers`.`t_teacher_baseinfo`.`degree_type`        AS `degree_type`,
         `jg_teachers`.`t_educate_degree`.`educate_degree_level` AS `educate_degree_level`,
         `jg_teachers`.`t_educate_degree`.`is_mentor`            AS `is_mentor`,
         `jg_teachers`.`t_educate_degree`.`major`                AS `major`,
         `jg_teachers`.`t_educate_degree`.`tutor_class`          AS `tutor_class`,
         `jg_teachers`.`t_educate_degree`.`mentor_type`          AS `mentor_type`,
         `jg_teachers`.`t_educate_degree`.`for_class`            AS `for_class`,
         `jg_teachers`.`t_teacher_baseinfo`.`identityNum`        AS `identityNum`,
         `jg_teachers`.`t_users`.`account`                       AS `account`,
         `jg_teachers`.`t_users`.`password`                      AS `password`,
         `jg_teachers`.`t_users`.`id`                            AS `id`,
         `jg_teachers`.`t_users`.`create_time`                   AS `create_time`
  from (((`jg_teachers`.`t_users_role` left join `jg_teachers`.`t_teacher_baseinfo` on ((
    `jg_teachers`.`t_users_role`.`user_id` =
    `jg_teachers`.`t_teacher_baseinfo`.`user_id`))) left join `jg_teachers`.`t_educate_degree` on ((
    `jg_teachers`.`t_users_role`.`user_id` =
    `jg_teachers`.`t_educate_degree`.`user_id`))) join `jg_teachers`.`t_users` on ((
    `jg_teachers`.`t_users_role`.`user_id` = `jg_teachers`.`t_users`.`id`)));

